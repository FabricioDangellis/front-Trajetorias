import { useState } from "react";
import "./PatientList.css";

import avatar1 from "../../assets/menina1.jpg";
import avatar2 from "../../assets/menino1.jpg";


import { IoCloseOutline } from "react-icons/io5";
import { NavLink } from "react-router-dom";

interface Patient {
    id: number;
    name: string;
    status: "Ativo" | "Inativo";
    lastAppointment: string;
    avatar: string;
    guardianName: string;
    birthDate: string;
    aboutPatient: string;
    description: string;
}

const mockPatients: Patient[] = [
    {
        id: 1,
        name: "Laura Mendes",
        status: "Ativo",
        lastAppointment: "10/06/2025",
        avatar: avatar1,
        guardianName: "Fernanda Mendes",
        birthDate: "15/05/2015",
        aboutPatient: "Gosta de livros e de comer brigadeiro de colher",
        description: "Paciente em acompanhamento desde 2023. Apresenta boa evolução emocional.",
    },
    {
        id: 2,
        name: "João Silva",
        status: "Inativo",
        lastAppointment: "22/05/2025",
        avatar: avatar2,
        guardianName: "Carlos Silva",
        birthDate: "20/08/2014",
        aboutPatient: "Gosta de brincar com seu cachorro Bolinha e se fantasiar com o pijama de dinossauro",
        description: "Paciente ausente nas últimas sessões. Histórico de ansiedade.",
    },
];

export function PatientList() {
    const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
    const [search, setSearch] = useState("");

    const filteredPatients = mockPatients.filter((patient) =>
        patient.name.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="patients-container">

            <div className="menuLista">
                <input
                    type="text"
                    placeholder="Buscar paciente"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                />
                
                <button>
                    Cadastrar Paciente
                </button>
            </div>


            <div className="corpoLista">
                <div className="patient-list">
                    <div className="titulo">
                        <div className="nome">Paciente</div>
                        <div className="status">Status</div>
                        <div className="ultimaSessao">Ultimo Atendimento</div>
                    </div>

                    {filteredPatients.map((patient) => (
                        <div
                            key={patient.id}
                            className={`patient-item ${selectedPatient?.id === patient.id ? "selected" : ""}`}
                            onClick={() => setSelectedPatient(patient)}
                        >
                            <div className="nome">
                                <img src={patient.avatar} alt={patient.name} />
                                <h4>{patient.name}</h4>
                            </div>
                            <div className="status">
                                <p>{patient.status}</p>
                            </div>
                            <div className="ultimaSessao">
                                <p>{patient.lastAppointment}</p>
                            </div>
                        </div>
                    ))}
                </div>

                {selectedPatient && (
                    <div className="patient-detail">
                        <button
                            className="close-button"
                            onClick={() => setSelectedPatient(null)}
                        >
                            <IoCloseOutline className="icone" />
                        </button>

                        <img src={selectedPatient.avatar} />
                        <h2>{selectedPatient.name}</h2>
                        <p>{selectedPatient.birthDate}</p>
                        <p>{selectedPatient.guardianName}</p>
                        <p className="sobrePaciente">
                            <strong>Sobre {selectedPatient.name}:</strong> {selectedPatient.aboutPatient}
                        </p>
                        <p className="descricaoPaciente">
                            <strong>Informes: </strong>{selectedPatient.description}
                        </p>
                        <NavLink className="botaoExibir" to={`/pacientes/perfilPacientes/${selectedPatient.id}`}> 
                            <strong>Exibir Paciente</strong> 
                        </NavLink>
                    </div>
                )}
            </div>
        </div>
    );
}
