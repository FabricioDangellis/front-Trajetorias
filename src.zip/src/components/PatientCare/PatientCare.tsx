import { useState } from "react";
import "./PatientCare.css";

interface Appointment {
  id: number;
  date: string;
  time: string;
  status: "Confirmada" | "Cancelada" | "Pendente";
  type: "Individual" | "Familiar" | "Retorno";
}

const upcomingAppointments: Appointment[] = [
  { id: 1, date: "15/06/2025", time: "14:00", status: "Confirmada", type: "Individual" },
  { id: 2, date: "20/06/2025", time: "09:00", status: "Pendente", type: "Retorno" },
];

const pastAppointments: Appointment[] = [
  { id: 3, date: "10/06/2025", time: "15:00", status: "Confirmada", type: "Individual" },
  { id: 4, date: "05/06/2025", time: "13:00", status: "Cancelada", type: "Familiar" },
];

export function PatientCare() {
  const [activeTab, setActiveTab] = useState<"upcoming" | "past">("upcoming");

  const appointmentsToShow = activeTab === "upcoming" ? upcomingAppointments : pastAppointments;

  return (
    <div className="patient-care">

      <div className="tabs">
        <button
          className={activeTab === "upcoming" ? "active" : ""}
          onClick={() => setActiveTab("upcoming")}
        >
          Próximas Consultas
        </button>
        <button
          className={activeTab === "past" ? "active" : ""}
          onClick={() => setActiveTab("past")}
        >
          Consultas Passadas
        </button>
      </div>

      <div className="appointment-list">
        {appointmentsToShow.length === 0 ? (
          <p>Nenhuma consulta registrada.</p>
        ) : (
          appointmentsToShow.map((appt) => (
            <div key={appt.id} className={`appointment-card ${appt.status.toLowerCase()}`}>
              <div>
                <strong>{appt.date}</strong> às <strong>{appt.time}</strong>
              </div>
              <p>Tipo: {appt.type}</p>
              <span className={`tipo ${appt.status.toLowerCase()}`}>
                {appt.status}
              </span>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
