import { useState } from "react";
import "./AppointmentList.css";
import avatar1 from "../../assets/menina1.jpg";
import avatar2 from "../../assets/menino1.jpg";

const mockAppointments = [
    {
        id: 1,
        patient: "Laura Mendes",
        time: "14:00",
        status: "Confirmado",
        type: "Individual",
        date: "2025-06-11",
        avatar: avatar1,
    },
    {
        id: 2,
        patient: "João Silva",
        time: "16:00",
        status: "Pendente",
        type: "Retorno",
        date: "2025-06-11",
        avatar: avatar2,
    },
];

const tabs = ["Hoje", "Todos", "Confirmado", "Pendente", "Cancelado"];

export function AppointmentList() {
    const [activeTab, setActiveTab] = useState("Hoje");

    const today = new Date().toISOString().split("T")[0];

    const filteredAppointments = mockAppointments.filter((a) => {
        if (activeTab === "Hoje") return a.date === today;
        if (activeTab === "Todos") return true;
        return a.status === activeTab;
    });

    return (
        <div className="listaAtendimentos">

            <div className="tabs">
                {tabs.map((tab) => (
                    <button
                        key={tab}
                        className={tab === activeTab ? "active" : ""}
                        onClick={() => setActiveTab(tab)}
                    >
                        {tab}
                    </button>
                ))}
            </div>

            <div className="titulo">
                <div className="paciente">Paciente</div>
                <div className="horario">Horário</div>
                <div className="tipoAtendimento">Tipo</div>
                <div className="status">Status</div>
                <div className="visualizar"></div>
            </div>

            <div className="appointment-list">
                {filteredAppointments.length === 0 ? (
                    <p className="empty-message">Nenhum atendimento encontrado.</p>
                ) : (
                    filteredAppointments.map((a) => (
                        <div key={a.id} className="appointment-item">
                            <div className="paciente">
                                <img src={a.avatar} alt={a.patient} />
                                <strong>{a.patient}</strong>
                            </div>
                            <div className="horario">
                                <span>{a.time}</span>
                            </div>
                            <div className="tipoAtendimento">
                                <p>{a.type}</p>
                            </div>
                            <div className="status">
                                <span className={`statusAtendimento ${a.status.toLowerCase()}`}>
                                    {a.status}
                                </span>
                            </div>
                            <div className="visualizar">
                                <button className="details-button">
                                    Visualizar consulta
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
}
