import FullCalendar from "@fullcalendar/react";
import dayGridPlugin from "@fullcalendar/daygrid";
import timeGridPlugin from "@fullcalendar/timegrid";
import interactionPlugin from "@fullcalendar/interaction";
import { useState } from "react";
import "./CalendarComponent.css";
import { ModalConsulta } from "../ModalConsulta/ModalConsulta";


const events = [
  {
    id: "1",
    title: "Laura Mendes",
    start: "2025-06-11T14:00:00",
    end: "2025-06-11T15:00:00",
    className: "confirmado",
    extendedProps: {
      status: "Confirmado",
      tipo: "Individual",
    },
  },
  {
    id: "2",
    title: "João Silva",
    start: "2025-06-12T09:00:00",
    end: "2025-06-12T10:00:00",
    className: "pendente",
    extendedProps: {
      status: "Pendente",
      tipo: "Familiar",
    },
  },
  {
    id: "3",
    title: "Ana Clara",
    start: "2025-06-13T11:00:00",
    end: "2025-06-13T12:00:00",
    className: "cancelado",
    extendedProps: {
      status: "Cancelado",
      tipo: "Retorno",
    },
  },
];

export function CalendarComponent() {
  const [selectedEvent, setSelectedEvent] = useState<any>(null);

  function handleEventClick(info: any) {
    setSelectedEvent({
      id: info.event.id,
      title: info.event.title,
      start: info.event.startStr,
      end: info.event.endStr,
      status: info.event.extendedProps.status,
      tipo: info.event.extendedProps.tipo,
    });
  }

  return (
    <div className="calendar-container">
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="timeGridWeek"
        initialDate="2025-06-11"
        headerToolbar={{
          start: "dayGridMonth,timeGridWeek,timeGridDay",
          center: "title",
          end: "prev,next today",
        }}
        events={events}
        eventClick={handleEventClick}
        height="auto"
        locale="pt-br"
        slotMinTime="07:00:00"
        slotMaxTime="20:00:00"
      />

      {selectedEvent && (
        <ModalConsulta
          event={selectedEvent}
          onClose={() => setSelectedEvent(null)}
        />
      )}
    </div>
  );
}