import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./style.css";
import { Link } from "react-router-dom";
import { api } from "../../services/api";

import Logo from "../../assets/Logo.svg"
import Psicologa from "../../assets/Psicologa.svg"
import { FcGoogle } from "react-icons/fc";
import { FaFacebook } from "react-icons/fa6";
import { TextInput } from "../../components/Input/TextInputProps";

export default function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();

    try {
      const response = await api.post("/session", {
        email,
        password,
      });

      const token = response.data.token;

      localStorage.setItem("token", token);
      localStorage.setItem("name", response.data.user.name);
      navigate("/dashboard");
    } catch (err: any) {
      alert("Erro ao fazer login. Verifique suas credenciais.");
      console.error(err);
    }

    /*if (email === "admin@example.com" && password === "123456") {
      localStorage.setItem("token", "fake-token");
      navigate("/dashboard");
    } else {
      alert("Credenciais inválidas");
    }*/
  }

  return (
    <div className='container Login'>

      <div className='sessao'>

        <div className="formulario">

          <h2>Acesse sua jornada</h2>
          <span>Cuidar do bem-estar começa com um simples passo. 
            Faça login para acompanhar o desenvolvimento emocional 
            das crianças.
          </span>

          <form onSubmit={handleLogin}>
             <TextInput
              type="email"
              title="Email"
              placeholder="E-mail"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              label="E-mail"
              required
            />
            <TextInput
              type="password"
              title="Senha"
              placeholder="Senha"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              label="Senha"
              required
            />
            <Link className="
            
            " to={"/dashboard"}>Esqueci minha senha</Link>

            <button type="submit">Entrar</button>
          </form>

          <h3>ou</h3>

            <div className="logins">
              <button title="Faça login com o Google" className="google">
                <FcGoogle className="iconeLogin"/>
              </button>

              <button title="Faça login com o Facebook" className="facebook">
                <FaFacebook  className="iconeLogin" />
              </button>
            </div>

          <span>Ainda não tem uma conta? <Link to={"/cadastro"}>Cadastre-se</Link></span>

        </div>
      </div>
      
      <div className="sessao">
        <img src={Logo} className="logo" />

        <div className="painel"></div>

        <img src={Psicologa} className="imagemPs" />
      </div>
    </div>
  );
}
