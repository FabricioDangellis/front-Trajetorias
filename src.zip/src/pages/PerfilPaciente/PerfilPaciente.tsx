import { useNavigate, useParams } from "react-router-dom";
import "./PerfilPaciente.css"
import { Sidebar } from "../../components/SideBar/SideBar";
import avatar1 from "../../assets/menina1.jpg";
import avatar2 from "../../assets/menino1.jpg";
import { PatientCare } from "../../components/PatientCare/PatientCare";
import { CiCirclePlus, CiImport  } from "react-icons/ci";

interface Patient {
    id: number;
    name: string;
    status: "Ativo" | "Inativo";
    lastAppointment: string;
    avatar: string;
    guardianName: string;
    birthDate: string;
    aboutPatient: string;
    description: string;
}

const mockPatients: Patient[] = [
    {
        id: 1,
        name: "Laura Mendes",
        status: "Ativo",
        lastAppointment: "10/06/2025",
        avatar: avatar1,
        guardianName: "Fernanda Mendes",
        birthDate: "15/05/2015",
        aboutPatient: "Gosta de livros e de comer brigadeiro de colher",
        description: "Paciente em acompanhamento desde 2023. Apresenta boa evolução emocional.",
    },
    {
        id: 2,
        name: "João Silva",
        status: "Inativo",
        lastAppointment: "22/05/2025",
        avatar: avatar2,
        guardianName: "Carlos Silva",
        birthDate: "20/08/2014",
        aboutPatient: "Gosta de brincar com seu cachorro Bolinha e se fantasiar com o pijama de dinossauro",
        description: "Paciente ausente nas últimas sessões. Histórico de ansiedade.",
    },
];



export default function PerfilPaciente() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const paciente = mockPatients.find((p) => p.id === Number(id));

    function handleLogout() {
        localStorage.removeItem("token");
        navigate("/login");
    }

    if (!paciente) {
        return <p>Paciente não encontrado.</p>;
    }

    const mockDocuments = [
        { id: 1, name: "Relatório de Evolução", date: "01/06/2025" },
        { id: 2, name: "Plano Terapêutico", date: "15/05/2025" },
        { id: 3, name: "Ficha de Anamnese", date: "10/04/2025" },
    ];

    return (
        <div className="container perfilPaciente">
            <Sidebar onLogout={handleLogout} />

            <main className="content">

                <section className="mainSection">
                    <div className="topo">
                        <h2>Pacientes - Perfil Paciente</h2>
                    </div>

                    <div className="conteudo">
                        <div className="principal">

                            <div className="dadosPaciente">
                                <div className="paciente">
                                    <img src={paciente.avatar} />
                                    <h3>{paciente.name}</h3>
                                </div>

                                <div className="informesGerais">
                                    <h3><strong>Informações Gerais</strong></h3>

                                    <div className="grid-infos">
                                        <p><strong>Nascimento:</strong></p>
                                        <p>{paciente.birthDate}</p>

                                        <p><strong>Responsável:</strong></p>
                                        <p>{paciente.guardianName}</p>

                                        <p><strong>Sobre:</strong></p>
                                        <p>{paciente.aboutPatient}</p>

                                        <p><strong>Descrição:</strong></p>
                                        <p>{paciente.description}</p>
                                    </div>
                                </div>
                            </div>

                            <div className="listasQuadros">

                                <div className="atendimentos">
                                    <PatientCare />
                                </div>

                            </div>

                        </div>

                        <div className="documentos">
                            <div className="cabecalhoDocumentos">
                                <h3><strong>Documentos</strong></h3>
                                <button className="adicionarDocumento">
                                    <CiCirclePlus className="icone" />
                                </button>
                            </div>

                            <ul className="listaDocumentos">
                                {mockDocuments.map((doc) => (
                                    <li key={doc.id} className="document-item">
                                        <div className="info">
                                            <p className="doc-name">{doc.name}</p>
                                            <span className="doc-date">{doc.date}</span>
                                        </div>
                                        <button className="downlod-button">
                                            <CiImport className="icone" />
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                </section>



            </main>
        </div>
    );
}